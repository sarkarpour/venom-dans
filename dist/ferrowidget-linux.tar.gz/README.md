# FerroWidget Linux Standalone Installer

To install FerroWidget on any Linux distribution (Ubuntu, Debian, Fedora, Arch Linux, openSUSE):

1. Open a terminal in this directory.
2. Run the installer script:
   bash install_linux.sh

3. Run the widget:
   ferrowidget run
